const express = require("express");
const cors = require("cors");
const app = express();
const jwt = require("jsonwebtoken");

app.use(cors());
app.use(express.json());

const mysql = require("mysql");

let db_con = mysql.createConnection({
    host: "192.168.2.8",
    user: "trainee",
    password: 'trainee@123',
    database: 'trainee'
});

db_con.connect((err) => {
    if (err) {
        console.log("Database Connection Failed !!!", err);
    } else {
        console.log("connected to Database");
    }
});


app.get('/Register', function (req, res) { 
    console.log(req.query); 
    let Firstname = req.query.Firstname; 
    let Lastname = req.query.Lastname; 
    let Email = req.query.Email; 
    let Password = req.query.Password;
    let mobile = req.query.mobile;
    let gender = req.query.gender;
    let address = req.query.address;
    let dob = req.query.dob;

    let name = jwt.sign(Email, 'Hello');
    // let date = new Date();
    // let date1 = date.toJSON().slice(0, 10);

    var query = `INSERT INTO  (Firstname, Lastname, Email, Password, Mobile, Gender, address, dob, accesstoken) VALUES ("${Firstname}", "${Lastname}", "${email}", "${password}", "${mobile}", "${gender}", "${address}", "${dob}", "${name}")`; 
    db_con.query(query, function (err, results) { 
        if (err) throw err; 
        return res.send({ data: results, message: 'Data Added successfully.' }); 
    }); 
});


app.get('/Login', function (req, res) { 
    console.log(req.query); 
    let Email = req.query.Email; 
    let Password = req.query.Password; 
    let name = jwt.sign(Email, 'bhavya');
    

    if(Email && Password)
    {
        var query = `select * from registration19 where Email = "${Email}"`; 

        db_con.query(query, function (err, results) { 
            if (err) throw err; 
            if(results.length > 0){
                for(var count = 0; count < results.length; count++) {
                    if(results[count].password == password){
                        db_con.query(`Update registration19 SET accesstoken = "${name}" where Email = "${Email}"`, function(err, results){
                            
                            db_con.query(`Select Firstname, Lastname, accesstoken from registration19 where Email = "${Email}"`, function(err, results){
                                res.send(results);
                            });
                        })
                    }
                    else {
                        console.log("Invalid Password");
                        return res.send("Invalid Password");
                    }
                }
            }
            else {
                console.log("Invalid Email");
                return res.send("Invalid Email");
            } 
        });

    }
});

app.get("/Profile", async function (req, res) {
    console.log(req.query.token); 
   try{
    const ans = await resolveToken(req.query.token);
    db_con.query(`Select * from registration19 where Email = "${ans}"` , function(err, results){
        if (err) throw err;
        res.send(results);
    })
   }catch(err){
    res.send("error");
   }
});


app.get("/Update",  function (req, res) {
    console.log(req.query.token); 
   db_con.query(`Update registration19 SET Firstname = "${req.query.Firstname}", Lastname = "${req.query.Lastname}", Password = "${req.query.Password}", mobile="${req.query.mobile}", gender="${req.query.gender}", address="${req.query.address}", dob="${req.query.dob}" where Email="${req.query.Email}"`, function(err, results){
    if(err) throw err;
    res.send(results);
   })
});


app.get("/getproduct", (req, res) => {
    db_con.query(`select * from product_cus`, function(err, results){
        if (err) throw err;
        res.send(results);
    })
})


const resolveToken = (token) => {
    console.log("Token : ", token);
    return new Promise((resolve, reject) => {
        jwt.verify(token, "bhavya", function(err, results){
            if (err) reject (err);
            console.log(decoded);
            resolve(decoded);
        })
    })
}



app.get("/", (req, res) => {
  res.json({ message: "Hello from server!" });
});

app.listen(9000, () => {
  console.log(`Server is running on port 9000.`);
});