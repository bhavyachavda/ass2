import logo from './logo.svg';
import './App.css';
// import * from "@material-ui/core"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from './Home';
import Registration from './Registration';
import Login from './Login';
import Header from './Header'
import Product from './Product';
import Profile from './Profile';


function App() {
  return (
    <div className="App">

      <Router>
        <Routes>
          <Route path="/" element={<Home />}></Route>

          <Route path="/registration" element={<Registration />}></Route>

          <Route path="/login" element={<Login />}></Route>

          <Route path="/Header" element={<Header />}></Route>

          <Route path="/Product" element={<Product />}></Route>

          <Route path="/Profile" element={<Profile />}></Route>

        </Routes>
      </Router>

      {/* <Registration />
      <Login /> */}
    </div>
  );
}

export default App;
