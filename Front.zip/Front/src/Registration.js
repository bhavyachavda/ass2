import React, {useState, useEffect} from 'react';
import axios from 'axios';
import { Navigate } from 'react-router-dom';
import Header from './Header';

function Registration()
{

    const [ans, setAns] = useState('');
    const [firstname, setFirstname] = useState('');
    const [lastname, setLastname] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [conpassword, setConpassword] = useState('');
    const [mobile, setMobile] = useState('');
    const [gender, setGender] = useState('');
    const [address, setAddress] = useState('');
    const [dob, setDOB] = useState('');

    const navigate = useState();


    useEffect(() => {
    }, [ans])

    useEffect(() => {
        getdata();
    }, [])

   
    function Register(e) {
        e.preventDefault();

        if(password === conpassword)
        {
            axios.get("http://localhost:9000/Register",{params: { firstname: firstname, lastname: lastname, email: email, password: password, conpassword: conpassword, mobile: mobile, gender: gender, address: address, dob: dob}}).then((res) => {
            console.log(res);
            navigate("/Login")
        });
        } else{
            alert("Password is not Matched");
        }
    }

    function getdata() {
        axios.get("http://localhost:9000/getdata").then((res) => {

            const ans = res.data;
            setAns(ans);
        });
    }



    return (
        <div>
            <Header />
            <form onSubmit={Register}>
                <h2>Registration</h2>
                <div>
                    <label htmlFor="fname">First Name</label>
                    <input type="text" name="fname" id="fname" value={firstname} onChange={(e) => { setFirstname(e.target.value) }} />
                </div> <br />


                <div>
                    <label htmlFor="lname">Last Name</label>
                    <input type="text" name="lname" id="lname" value={lastname} onChange={(e) => { setLastname(e.target.value) }} />
                </div> <br />



                <div>
                <label htmlFor="email">Email</label>
                    <input type='text' name="email" id="email" value={email} onChange={(e) => { setEmail(e.target.value) }} />
                </div> <br />


                <div>
                <label htmlFor="password">Password</label>
                    <input type='password' name="password" id="password" value={password} onChange={(e) => { setPassword(e.target.value) }} />
                </div> <br />


                <div>
                <label htmlFor="Conpassword">ConfirmPassword</label>
                    <input type='password' name="Conpassword" id="Conpassword" value={conpassword} onChange={(e) => { setConpassword(e.target.value) }} />
                </div> <br />

                <div>
                <label htmlFor="moblie">Mobile</label>
                    <input type='text' name="mobile" id="mobile" value={mobile} onChange={(e) => { setMobile(e.target.value) }} />
                </div> <br />

                <label htmlFor="gender">Gender: </label>
                    &nbsp;
                    <input
                        id="male"
                        type="radio"
                        name="gender"
                        value="male"
                        onChange={(e)=> setGender(e.target.value) }
                        checked={gender == "male" ? "true" : null}
                    />

                    <label htmlFor="male">Male</label>
                    &nbsp;
                    <input
                        id="female"
                        type="radio"
                        name="gender"
                        value="female"
                        onChange={(e) => setGender(e.target.value)}
                        checked={gender == "female" ? "true" : null}
                    />

                    <label htmlFor="female">Female</label><br />

                    <br />

                <div>
                <label htmlFor="address">Address</label>
                    <textarea type='text' name="address" id="address" row="10" col="50" value={address} onChange={(e) => { setAddress(e.target.value) }} />
                </div> <br />

                <div>
                <label htmlFor="address">DOB</label>
                    <input type='date' name="DOB" id="DOB" value={dob} onChange={(e) => { setDOB(e.target.value) }} />
                </div> <br />

                <div>
                    <input type='submit' value='submit'></input>
                </div>

            </form>
            
            <br></br>
        </div>
    )
}

export default Registration;