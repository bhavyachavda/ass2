import React, {useState, useEffect} from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function Profile()
{
    const [ans, setAns] = useState([]);
    const [firstname, setFirstname] = useState('');
    const [lastname, setLastname] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [mobile, setMobile] = useState('');
    const [gender, setGender] = useState('');
    const [address, setAddress] = useState('');
    const [dob, setDOB] = useState('');
    const navigate = useNavigate();
    const token = localStorage.getItem("key");

    function cancel()
    {
        navigate("/product");
    }

    function getdata(e)
    {
        axios.get("http://localhost:9000/Profile", {token}).then((res) => {
            console.log(res.data[0]);
            const ans = res.data[0];
            setFirstname(ans.firstname);
            setLastname(ans.lastname);
            setEmail(ans.email);
            setPassword(ans.password);
            setMobile(ans.mobile);
            setGender(ans.gender);
            setAddress(ans.address);
            setDOB(ans.dob.slice(0, 10));
        })
    }


    function Update(e){
        e.preventDefault();

        axios.get("http://localhost:9000/Profile",{params: { firstname: firstname, lastname: lastname, email: email, password: password, mobile: mobile, gender: gender, address: address, dob: dob}}).then((res) => {
            navigate("/product");
        })
    }

    useEffect(() => {
        getdata()
    }, []);


    useEffect(() => {
    }, [ans])


    return (
        <div>
            <form onSubmit={Update}>
                <h2>Update</h2>
                <div>
                    <label htmlFor="fname">First Name</label>
                    <input type="text" name="fname" id="fname" value={firstname} onChange={(e) => { setFirstname(e.target.value) }} required/>
                </div> <br />


                <div>
                    <label htmlFor="lname">Last Name</label>
                    <input type="text" name="lname" id="lname" value={lastname} onChange={(e) => { setLastname(e.target.value) }} required/>
                </div> <br />



                <div>
                <label htmlFor="email">Email</label>
                    <input type='text' name="email" id="email" value={email} onChange={(e) => { setEmail(e.target.value) }} />
                </div> <br />


                <div>
                <label htmlFor="password">Password</label>
                    <input type='password' name="password" id="password" value={password} onChange={(e) => { setPassword(e.target.value) }} required/>
                </div> <br />


                <div>
                <label htmlFor="moblie">Mobile</label>
                    <input type='text' name="mobile" id="mobile" value={mobile} onChange={(e) => { setMobile(e.target.value) }} required/>
                </div> <br />

                <label htmlFor="gender">Gender: </label>
                    &nbsp;
                    <input
                        id="male"
                        type="radio"
                        name="gender"
                        value="male"
                        onChange={(e)=> setGender(e.target.value) }
                        checked={gender == "male" ? "true" : null}
                    />

                    <label htmlFor="male">Male</label>
                    &nbsp;
                    <input
                        id="female"
                        type="radio"
                        name="gender"
                        value="female"
                        onChange={(e) => setGender(e.target.value)}
                        checked={gender == "female" ? "true" : null}
                    />

                    <label htmlFor="female">Female</label><br />

                    <br />

                <div>
                <label htmlFor="address">Address</label>
                    <textarea type='text' name="address" id="address" row="10" col="50" value={address} onChange={(e) => { setAddress(e.target.value) }} required/>
                </div> <br />

                <div>
                <label htmlFor="address">DOB</label>
                    <input type='date' name="DOB" id="DOB" value={dob} onChange={(e) => { setDOB(e.target.value) }} required/>
                </div> <br />

                <div>
                    <input type='submit' value='Update'></input> &nbsp;
                    <button onClick={cancel}>cancel</button>
                </div>

            </form>
            <br></br>
        </div>
    )
}

export default Profile;