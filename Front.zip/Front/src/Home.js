import React from 'react';
import Header from './Header';
import { Link } from "react-router-dom";

function Home()
{
    return (
        <div>
          <Header />
        <h1>Home Page</h1>
        <br />
        {/* <ul>
          <li>
            <Link to="/">Main</Link>
          </li>
          <li>
            <Link to="/registration">Registration</Link>
          </li>
          <li>
            <Link to="/login">Login</Link>
          </li>
        </ul> */}
      </div>
    )
}

export default Home;