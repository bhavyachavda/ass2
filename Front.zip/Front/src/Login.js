import React, { useEffect, useState } from "react";
import axios from 'axios';
import { useNavigate} from 'react-router-dom';
import Header from "./Header";


function Login()
{
    const [Email, setEmail] = useState('');
    const [Password, setPassword] = useState('');
    // const [Login, setLogin] = useState('');
    const navigate = useNavigate();
    function Logindetails(event) {
        event.preventDefault();

        axios.get("http://localhost:9000/Login",{params: { Email: Email, Password: Password}}).then((res) => {
            console.log(res.data);
            localStorage.setItem("key",res.data[0].accesstoken);
            localStorage.setItem("Firstname", res.data[0].Firstname);
            localStorage.setItem("Lastname", res.data[0].Lastname)
            navigate("/Product")
        });
    }

    return (
        <div >
            <Header />
            <form onSubmit={Logindetails}>
                <h2>Login</h2>
                <div>
                    <label htmlFor="email">Email</label>
                    <input type="text" name="email" id="email" value={Email} onChange={(e) => { setEmail(e.target.value) }} />
                </div> <br />


                <div>
                    <label htmlFor="Password">Password</label>
                    <input type="password" name="Password" id="Password" value={Password} onChange={(e) => { setPassword(e.target.value) }} />
                </div> <br />


                <div>
                    <input type='submit' value='submit'></input>
                </div>
            </form>
            
            <br></br>
        </div>

    )

}

export default Login;
